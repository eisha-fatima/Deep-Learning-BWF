#File Read And Write
#Exercise 10

# --- Q ->>> 10-1
with open('learning_python.txt') as file:
    file_text = file.read()
    print(file_text)

# Printing Using loop
with open('learning_python.txt') as file:
    for text_line in file:
        print(text_line)
#Making list of lines and then printing it.
with open('learning_python.txt') as file:
    text_line_list = file.readlines()
for line in text_line_list:
    print(line)
    
# --- Q ->>> 10-3
username = input("Enter Username: ")
with open('guest.txt','w') as file:
    file.write(username+'\n')

# --- Q ->>> 10-4
with open('guest_book.txt','a') as file:
    while (True):
        username = input("Enter username: ")
        file.write(username+': <= This User Visited the Screeb.\n')
        print('Helloooooooo to you '+username)

    
