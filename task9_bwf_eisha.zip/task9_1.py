# --- Q -->>> 10-6
def sum():
    try:
        num1 = int(input('Give number 1: '))
        num2 = int(input('Give number 2: '))   
        sum = num1 + num2 
        return sum
    except ValueError:
        err_message = "The text you entered was wrong."
        print(err_message)
        
print(sum())

# --- Q -->>>> 10-7
#continuing using continue keyword in case of wrong input
def sum():
    while(True):
        try:
            num1 = int(input('Give number 1: '))
            num2 = int(input('Give number 2: '))   
            sum = num1 + num2 
            return sum
        except ValueError:
            continue
#sum()

# --- Q -->>> 10-8
#Reading from multiple files

def read_multi_text_files(file):
    try:
        with open(file) as file:
            file_text = file.read()
            print('File Text: \n'+file_text)
    except FileNotFoundError:
        print('File You are looking for was not Found.')
        
file_list = ['cats_.txt','dogs_.txt']
for file in file_list:
    read_multi_text_files(file)